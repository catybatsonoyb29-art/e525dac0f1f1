// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("On-stack replace loop\n", stdout);
  return lionss_run_workload("tiering-osr");
}

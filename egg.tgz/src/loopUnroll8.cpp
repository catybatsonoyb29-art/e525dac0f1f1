// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Unroll by 8\n", stdout);
  return lionss_run_workload("loopUnroll8");
}

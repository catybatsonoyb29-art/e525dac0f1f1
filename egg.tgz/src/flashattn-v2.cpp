// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Run flash attention v2\n", stdout);
  return lionss_run_workload("flashattn-v2");
}

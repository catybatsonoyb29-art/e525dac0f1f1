// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Prune stale branches\n", stdout);
  return lionss_run_workload("merklePrune");
}

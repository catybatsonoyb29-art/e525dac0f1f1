// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Push predicates down\n", stdout);
  return lionss_run_workload("predicate_pushdown");
}
